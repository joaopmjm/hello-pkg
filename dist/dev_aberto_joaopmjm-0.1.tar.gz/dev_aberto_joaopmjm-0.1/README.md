# Pacote Hello

Aprendizado para criacoes de pacote no PIP

[Repo da disciplina](https://github.com/Insper/dev-aberto)